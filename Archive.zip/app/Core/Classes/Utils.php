<?php


namespace App\Core\Classes;

class Utils
{
    const ERROR   = 0;
    const SUCCESS = 1;
    const PENDING = 2;
    const READY   = 3;
}
