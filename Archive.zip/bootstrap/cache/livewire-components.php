<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
  'studio' => 'App\\Http\\Livewire\\Studio',
  'users' => 'App\\Http\\Livewire\\Users',
);