
            <?php
            $theme_name = 'METRONIC';
            $css = '<link href="../theme/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/plugins/custom/vis-timeline/vis-timeline.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/css/style.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/css/stylee.css" rel="stylesheet" type="text/css" id="app-style" />';
            $js = '<script src="../theme/plugins/global/plugins.bundle.js"></script>
<script src="../theme/js/scripts.bundle.js"></script>
<script src="../theme/plugins/custom/fslightbox/fslightbox.bundle.js"></script>
<script src="../theme/plugins/custom/typedjs/typedjs.bundle.js"></script>
<script src="../theme/js/custom/landing.js"></script>
<script src="../theme/js/custom/pages/pricing/general.js"></script>
<script src="../theme/plugins/custom/datatables/datatables.bundle.js"></script>
<script src="../theme/plugins/custom/vis-timeline/vis-timeline.bundle.js"></script>
<script src="../theme/js/widgets.bundle.js"></script>
<script src="../theme/js/custom/widgets.js"></script>
<script src="../theme/js/custom/apps/chat/chat.js"></script>
<script src="../theme/js/custom/utilities/modals/upgrade-plan.js"></script>
<script src="../theme/js/js/custom/utilities/modals/create-app.js"></script>
<script src="../theme/js/custom/utilities/modals/upgrade-plan.js"></script>
<script src="../theme/js/custom/utilities/modals/create-campaign.js"></script>
<script src="../theme/js/custom/utilities/modals/users-search.js"></script>';
        