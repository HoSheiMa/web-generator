
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="./theme/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="./theme/plugins/custom/vis-timeline/vis-timeline.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="./theme/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="./theme/css/style.bundle.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="./theme/css/stylee.css" rel="stylesheet" type="text/css" id="app-style" />
    </head>
    <body>
        <!--begin::Header Section-->
    <div class="mb-0" id="home">
        <!--begin::Wrapper-->
        <div class="bgi-no-repeat bgi-size-contain bgi-position-x-center bgi-position-y-bottom landing-dark-bg"
            style="background-image: url(./theme/media/svg/illustrations/landing.svg)">
            <!--begin::Header-->
            <div class="landing-header" data-kt-sticky="true" data-kt-sticky-name="landing-header" data-kt-sticky-offset="{default: '200px', lg: '300px'}">
                <!--begin::Container-->
                <div class="container">
                    <!--begin::Wrapper-->
                    <div class="d-flex align-items-center justify-content-between">
                        <!--begin::Logo-->
                        <div class="d-flex align-items-center flex-equal">
                            <!--begin::Mobile menu toggle-->
                            <button class="btn btn-icon btn-active-color-primary me-3 d-flex d-lg-none" id="kt_landing_menu_toggle">
                                <i class="ki-duotone ki-abstract-14 fs-2hx">
                                    <span class="path1"></span>
                                    <span class="path2"></span>
                                </i>
                            </button>
                            <!--end::Mobile menu toggle-->
                            <!--begin::Logo image-->
                            <a href="/home.php">
                                                                    <span class="text-white">google</span>
                                                            </a>
                            <!--end::Logo image-->
                        </div>
                        <!--end::Logo-->
                        <!--begin::Menu wrapper-->
                        <div class="d-lg-block" id="kt_header_nav_wrapper">
                            <div class="d-lg-block p-5 p-lg-0" data-kt-drawer="true" data-kt-drawer-name="landing-menu" data-kt-drawer-activate="{default: true, lg: false}"
                                data-kt-drawer-overlay="true" data-kt-drawer-width="200px" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_landing_menu_toggle"
                                data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav_wrapper'}">
                                <!--begin::Menu-->
                                <div class="menu menu-column flex-nowrap menu-rounded menu-lg-row menu-title-gray-600 menu-state-title-primary nav nav-flush fs-5 fw-semibold"
                                    id="kt_landing_menu">
                                    <!--begin::Menu item-->

                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./home.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Home</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./features.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Features</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./demos.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Demos</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./pricing.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Pricing</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./faqs.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Faqs</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./clients.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Clients</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                            <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./contact.php"
                                                data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">Contact</a>
                                            <!--end::Menu link-->
                                        </div>
                                                                                                                <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./cart.php" data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">
                                                <i class="ki-duotone ki-handcart text-gray-900 fs-2tx"></i>
                                                <span id="cart-count" class="badge badge-circle badge-danger ms-2">0</span>
                                            </a>
                                            <!--end::Menu link-->
                                        </div>
                                        <div class="menu-item ">
                                            <!--begin::Menu link-->
                                            <a class="menu-link nav-link active py-3 px-4 px-xxl-6 " href="./orders.php" data-kt-scroll-toggle="true" data-kt-drawer-dismiss="true">
                                                My Orders
                                            </a>
                                            <!--end::Menu link-->
                                        </div>
                                        <script>
                                            // Define the URL to fetch from
                                            // Use fetch to get the data
                                            setInterval(() => {
                                                fetch('./api/cart/count.php')
                                                    .then(response => {
                                                        // Check if the response is ok (status is in the range 200-299)
                                                        if (!response.ok) {
                                                            throw new Error('Network response was not ok ' + response.statusText);
                                                        }
                                                        // Parse the JSON from the response
                                                        return response.json();
                                                    })
                                                    .then(data => {
                                                        // Log the JSON data to see its structure
                                                        console.log(data);

                                                        // Access the 'total_count' value in the JSON data
                                                        if (data.total_count !== undefined) {
                                                            // console.log('Count:', data.total_count);
                                                            document.querySelector('#cart-count').innerHTML = data.total_count
                                                        } else {
                                                            console.log('Count not found in the response');
                                                        }
                                                    })
                                                    .catch(error => {
                                                        // Handle any errors that occurred during fetch
                                                        console.log('There was a problem with the fetch operation:', error);
                                                    });
                                            }, 2500);
                                        </script>
                                                                    </div>
                                <!--end::Menu-->
                            </div>
                        </div>
                        <!--end::Menu wrapper-->
                        <!--begin::Toolbar-->
                        
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Wrapper-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::Header-->
            <!--begin::Landing hero-->
            <div class="d-flex flex-column flex-center w-100 min-h-350px min-h-lg-500px px-9">
                <!--begin::Heading-->
                <div class="text-center mb-5 mb-lg-10 py-10 py-lg-20">
                    <!--begin::Title-->
                    <h1 style="background: linear-gradient(to right, #12CE5D 0%, #FFD80C 100%);-webkit-background-clip: text;-webkit-text-fill-color: transparent;"
                        class="text-white lh-base fw-bold fs-2x fs-lg-3x mb-6">
                        Ubold is a fully featured premium admin template
                    </h1>
                    <h3><span style="color:white">
                            <span id="kt_landing_hero_text">Ubold is a fully featured premium admin template built on top of awesome Bootstrap 4.4.1, modern web technology HTML5, CSS3 and jQuery. It has many ready to use hand crafted components.</span>
                        </span></h3>
                    <br>
                    <!--end::Title-->
                    <!--begin::Action-->
                    <a href="index.html" class="btn btn-primary">Try Metronic</a>
                    <!--end::Action-->
                </div>
                <!--end::Heading-->
                <!--begin::Clients-->
                <div class="d-flex flex-center flex-wrap position-relative px-5">
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Fujifilm">
                        <img src="./theme/media/svg/brand-logos/fujifilm.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Vodafone">
                        <img src="./theme/media/svg/brand-logos/vodafone.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="KPMG International">
                        <img src="./theme/media/svg/brand-logos/kpmg.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Nasa">
                        <img src="./theme/media/svg/brand-logos/nasa.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Aspnetzero">
                        <img src="./theme/media/svg/brand-logos/aspnetzero.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="AON - Empower Results">
                        <img src="./theme/media/svg/brand-logos/aon.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Hewlett-Packard">
                        <img src="./theme/media/svg/brand-logos/hp-3.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                    <!--begin::Client-->
                    <div class="d-flex flex-center m-3 m-md-6" data-bs-toggle="tooltip" title="Truman">
                        <img src="./theme/media/svg/brand-logos/truman.svg" class="mh-30px mh-lg-40px" alt="" />
                    </div>
                    <!--end::Client-->
                </div>
                <!--end::Clients-->
            </div>
            <!--end::Landing hero-->
        </div>
        <!--end::Wrapper-->
        <!--begin::Curve bottom-->
        <div class="landing-curve landing-dark-color mb-10 mb-lg-20">
            <svg viewBox="15 12 1470 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M0 11C3.93573 11.3356 7.85984 11.6689 11.7725 12H1488.16C1492.1 11.6689 1496.04 11.3356 1500 11V12H1488.16C913.668 60.3476 586.282 60.6117 11.7725 12H0V11Z"
                    fill="currentColor"></path>
            </svg>
        </div>
        <!--end::Curve bottom-->
    </div>

<div class="card m-5">
    <div class="card-body">
        <form id="kt_modal_new_card_form" method="POST" action="/payment" class="form fv-plugins-bootstrap5 fv-plugins-framework" action="">
            <h1>Shipping Address</h1>
            <div class="d-flex flex-column my-7 fv-row fv-plugins-icon-container">
                <!--begin::Label-->
                <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                    Address
                    <span class="required">
                        <Address></Address>
                    </span></label>


                <input required type="text" class="form-control form-control-solid" placeholder="Address" name="address" value="Cairo">
                <div class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback"></div>
            </div>
            <h1>Payment Details</h1>
            <!--end::Radio group-->
            <div class="d-flex flex-column my-7 fv-row fv-plugins-icon-container">
                <!--begin::Label-->
                <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                    <span class="required">Name On Card</span>


                    <span class="ms-1" data-bs-toggle="tooltip" aria-label="Specify a card holder's name" data-bs-original-title="Specify a card holder's name"
                        data-kt-initialized="1">
                        <i class="ki-outline ki-information-5 text-gray-500 fs-6"></i></span> </label>
                <!--end::Label-->

                <input required type="text" class="form-control form-control-solid" placeholder="" name="card_name" value="Max Doe">
                <div class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback"></div>
            </div>
            <!--end::Input group-->

            <!--begin::Input group-->
            <div class="d-flex flex-column mb-7 fv-row fv-plugins-icon-container fv-plugins-bootstrap5-row-invalid">
                <!--begin::Label-->
                <label class="required fs-6 fw-semibold form-label mb-2">Card Number</label>
                <!--end::Label-->

                <!--begin::Input wrapper-->
                <div class="position-relative">
                    <!--begin::Input-->
                    <input required type="text" class="form-control form-control-solid" placeholder="Enter card number" name="card_number" value="4111 1111 1111 1111">
                    <!--end::Input-->

                    <!--begin::Card logos-->
                    <div class="position-absolute translate-middle-y top-50 end-0 me-5">
                        <img src="/metronic8/demo4/assets/media/svg/card-logos/visa.svg" alt="" class="h-25px">
                        <img src="/metronic8/demo4/assets/media/svg/card-logos/mastercard.svg" alt="" class="h-25px">
                        <img src="/metronic8/demo4/assets/media/svg/card-logos/american-express.svg" alt="" class="h-25px">
                    </div>
                    <!--end::Card logos-->
                </div>
                <!--end::Input wrapper-->
                <div class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                    <div data-field="card_number" data-validator="notEmpty">Card member is required</div>
                </div>
            </div>
            <!--end::Input group-->

            <!--begin::Input group-->
            <div class="row mb-10">
                <!--begin::Col-->
                <div class="col-md-8 fv-row">
                    <!--begin::Label-->
                    <label class="required fs-6 fw-semibold form-label mb-2">Expiration Date</label>
                    <!--end::Label-->

                    <!--begin::Row-->
                    <div class="row fv-row fv-plugins-icon-container">
                        <!--begin::Col-->
                        <div class="col-6">
                            <select name="card_expiry_month" required class="form-select form-select-solid " data-kt-initialized="1">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </select>
                        </div>
                        <!--end::Col-->

                        <!--begin::Col-->
                        <div class="col-6">
                            <select name="card_expiry_year" required class="form-select form-select-solid ">
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                            </select>
                        </div>
                        <!--end::Col-->
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Col-->

                <!--begin::Col-->
                <div class="col-md-4 fv-row fv-plugins-icon-container">
                    <!--begin::Label-->
                    <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                        <span class="required">CVV</span>


                        <span class="ms-1" data-bs-toggle="tooltip" aria-label="Enter a card CVV code" data-bs-original-title="Enter a card CVV code" data-kt-initialized="1">
                            <i class="ki-outline ki-information-5 text-gray-500 fs-6"></i></span> </label>
                    <!--end::Label-->

                    <!--begin::Input wrapper-->
                    <div class="position-relative">
                        <!--begin::Input-->
                        <input required type="text" class="form-control form-control-solid" minlength="3" maxlength="4" placeholder="CVV" name="card_cvv">
                        <!--end::Input-->

                        <!--begin::CVV icon-->
                        <div class="position-absolute translate-middle-y top-50 end-0 me-3">
                            <i class="ki-outline ki-credit-cart fs-2hx"></i>
                        </div>
                        <!--end::CVV icon-->
                    </div>
                    <!--end::Input wrapper-->
                    <div class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback"></div>
                </div>
                <!--end::Col-->
            </div>
            <!--end::Input group-->

            <!--begin::Input group-->
            <div class="d-flex flex-stack">
                <!--begin::Label-->
                <div class="me-5">
                    <label class="fs-6 fw-semibold form-label">Save Card for further billing?</label>
                    <div class="fs-7 fw-semibold text-muted">If you need more info, please check budget planning</div>
                </div>
                <!--end::Label-->

                <!--begin::Switch-->
                <label class="form-check form-switch form-check-custom form-check-solid">
                    <input class="form-check-input" type="checkbox" value="1" checked="checked">
                    <span class="form-check-label fw-semibold text-muted">
                        Save Card
                    </span>
                </label>
                <!--end::Switch-->
            </div>
            <!--end::Input group-->


            <!--begin::Actions-->
            <div class="text-center pt-15">
                <a href="./home.php" class="btn btn-light me-3">
                    Discard
                </a>

                <button type="button" onclick="checkout(this)" id="kt_button_1" class="btn btn-primary" load>
                    <span class="indicator-label">
                        Pay
                    </span>
                    <span class="indicator-progress">
                        Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                </button>
            </div>
            <!--end::Actions-->
        </form>
        <div id="success-message" style="display: none;" class="alert alert-success mt-3">
            Payment successful! Redirecting to home page...
        </div>
        <div id="error-message" style="display: none;" class="alert alert-danger mt-3">

        </div>
    </div>
</div>

<script>
    checkout = (btn) => {
        const form = document.getElementById('kt_modal_new_card_form');
        const formData = new FormData(form);

        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        btn.setAttribute('data-kt-indicator', "on");

        fetch('./api/orders/checkout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.status == "error") {
                    document.getElementById('error-message').innerText = result.message;
                    document.getElementById('error-message').style.display = 'block';
                    return;
                }
                btn.removeAttribute('data-kt-indicator', "on");

                console.log('Success:', result);
                document.getElementById('success-message').style.display = 'block';
                setTimeout(() => {
                    window.location.href = './home.php';
                }, 3000);
            })
            .catch(error => {
                console.error('Error:', error);
                // Handle error
            });
    }
</script>

<!--begin::Footer Section-->
    <div class="mb-0">
        <!--begin::Curve top-->
        <div class="landing-curve landing-dark-color">
            <svg viewBox="15 -1 1470 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M1 48C4.93573 47.6644 8.85984 47.3311 12.7725 47H1489.16C1493.1 47.3311 1497.04 47.6644 1501 48V47H1489.16C914.668 -1.34764 587.282 -1.61174 12.7725 47H1V48Z"
                    fill="currentColor"></path>
            </svg>
        </div>
        <!--end::Curve top-->
        <!--begin::Wrapper-->
        <div class="landing-dark-bg pt-20">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Row-->
                <div class="row py-10 py-lg-20">
                    <!--begin::Col-->
                    <div class="col-lg-6 pe-lg-16 mb-10 mb-lg-0">
                        <!--begin::Block-->
                        <div class="rounded landing-dark-border p-9 mb-10">
                            <!--begin::Title-->
                            <h2 class="text-white">
                                                                    <span class="text-white">google dogs.com</span>
                                                            </h2>
                            <!--end::Title-->
                            <!--begin::Text-->
                            <span class="fw-normal fs-4 text-gray-700">Email us to
                                <a href="https://keenthemes.com/support" class="text-white opacity-50 text-hover-primary">support@WebHybrid.com</a></span>
                            <!--end::Text-->
                        </div>
                        <!--end::Block-->
                        <!--begin::Block-->
                        <div class="rounded landing-dark-border p-9">
                            <!--begin::Title-->
                            <h2 class="text-white">A Responsive Bootstrap 4 Web App Kit</h2>
                            <!--end::Title-->
                            <!--begin::Text-->
                            <span class="fw-normal fs-4 text-gray-700">Ubold is a fully featured premium admin template built on top of
                            awesome Bootstrap 4.1.3, modern web technology HTML5, CSS3 and
                            jQuery..
                                <a href="pages/user-profile/overview.html" class="text-white opacity-50 text-hover-primary">Click to Get a Quote</a></span>
                            <!--end::Text-->
                        </div>
                        <!--end::Block-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Col-->
                    <div class="col-lg-6 ps-lg-16">
                        <!--begin::Navs-->
                        <div class="d-flex justify-content-center">
                            <!--begin::Links-->
                            <div class="d-flex fw-semibold flex-column me-20">
                                <!--begin::Subtitle-->
                                <h4 class="fw-bold text-gray-500 mb-6">More Links</h4>
                                <!--end::Subtitle-->
                                <!--begin::Link-->

                                                                    <a href="./home.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Home</a>
                                                                    <a href="./features.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Features</a>
                                                                    <a href="./demos.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Demos</a>
                                                                    <a href="./pricing.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Pricing</a>
                                                                    <a href="./faqs.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Faqs</a>
                                                                    <a href="./clients.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Clients</a>
                                                                    <a href="./contact.php" class="text-white opacity-50 text-hover-primary fs-5 mb-6">Contact</a>
                                                            </div>
                            <!--end::Links-->
                            <!--begin::Links-->
                            <div class="d-flex fw-semibold flex-column ms-lg-20">
                                <!--begin::Subtitle-->
                                <h4 class="fw-bold text-gray-500 mb-6">Stay Connected</h4>
                                <!--end::Subtitle-->
                                <!--begin::Link-->
                                <a href="/" class="mb-6">
                                    <img src="/metronic/media/svg/brand-logos/facebook-4.svg" class="h-20px me-2" alt="" />
                                    <span class="text-white opacity-50 text-hover-primary fs-5 mb-6">Facebook</span>
                                </a>
                                <!--end::Link-->
                                <!--begin::Link-->
                                <a href="/" class="mb-6">
                                    <img src="/metronic/media/svg/brand-logos/twitter.svg" class="h-20px me-2" alt="" />
                                    <span class="text-white opacity-50 text-hover-primary fs-5 mb-6">Twitter</span>
                                </a>
                                <!--end::Link-->
                                <!--begin::Link-->
                                <a href="/" class="mb-6">
                                    <img src="/metronic/media/svg/brand-logos/instagram-2-1.svg" class="h-20px me-2" alt="" />
                                    <span class="text-white opacity-50 text-hover-primary fs-5 mb-6">Instagram</span>
                                </a>
                                <!--end::Link-->
                            </div>
                            <!--end::Links-->
                        </div>
                        <!--end::Navs-->
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
            <!--begin::Separator-->
            <div class="landing-dark-separator"></div>
            <!--end::Separator-->
            <!--begin::Container-->
            <div class="container">
                <!--begin::Wrapper-->
                <div class="d-flex flex-column flex-md-row flex-stack py-7 py-lg-10">
                    <!--begin::Copyright-->
                    <div class="d-flex align-items-center order-2 order-md-1">
                        <!--begin::Logo-->
                        <a href="/">
                                                            <span class="text-white">google dogs.com</span>
                                                    </a>
                        <!--end::Logo image-->
                        <!--begin::Logo image-->
                        <span class="mx-5 fs-6 fw-semibold text-gray-600 pt-1" href="www.webhybrid.com"> 2024&copy; Web Hybrid.</span>
                        <!--end::Logo image-->
                    </div>
                    <!--end::Copyright-->
                    <!--begin::Menu-->

                    <!--end::Menu-->
                </div>
                <!--end::Wrapper-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::Wrapper-->
    </div>
    <!--end::Footer Section-->
    <!--begin::Scrolltop-->
    <div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
        <i class="ki-outline ki-arrow-up"></i>
    </div>
    <!--end::Scrolltop-->
    </div>
    <!--end::Root-->
    <!--begin::Scrolltop-->
    <div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
        <i class="ki-outline ki-arrow-up"></i>
    </div>

        <script src="./theme/plugins/global/plugins.bundle.js"></script>
<script src="./theme/js/scripts.bundle.js"></script>
<script src="./theme/plugins/custom/fslightbox/fslightbox.bundle.js"></script>
<script src="./theme/plugins/custom/typedjs/typedjs.bundle.js"></script>
<script src="./theme/js/custom/landing.js"></script>
<script src="./theme/js/custom/pages/pricing/general.js"></script>
<script src="./theme/plugins/custom/datatables/datatables.bundle.js"></script>
<script src="./theme/plugins/custom/vis-timeline/vis-timeline.bundle.js"></script>
<script src="./theme/js/widgets.bundle.js"></script>
<script src="./theme/js/custom/widgets.js"></script>
<script src="./theme/js/custom/apps/chat/chat.js"></script>
<script src="./theme/js/custom/utilities/modals/upgrade-plan.js"></script>
<script src="./theme/js/js/custom/utilities/modals/create-app.js"></script>
<script src="./theme/js/custom/utilities/modals/upgrade-plan.js"></script>
<script src="./theme/js/custom/utilities/modals/create-campaign.js"></script>
<script src="./theme/js/custom/utilities/modals/users-search.js"></script>
    </body>
</html>
        