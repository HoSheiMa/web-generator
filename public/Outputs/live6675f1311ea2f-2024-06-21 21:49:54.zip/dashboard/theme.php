
            <?php
            $theme_name = 'UBOLD';
            $css = '<link href="../theme/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../theme/css/style.css" rel="stylesheet" type="text/css" id="app-style" />';
            $js = '<script src="../theme/js/jquery.min.js"></script>
<script src="../theme/js/bootstrap.bundle.min.js"></script>
<script src="../theme/js/jquery.easing.min.js"></script>
<script src="../theme/js/scrollspy.min.js"></script>
<script src="../theme/js/app.js"></script>';
            $cssdeep = '<link href="../../theme/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../../theme/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../../theme/css/style.css" rel="stylesheet" type="text/css" id="app-style" />';
            $jsdeep = '<script src="../../theme/js/jquery.min.js"></script>
<script src="../../theme/js/bootstrap.bundle.min.js"></script>
<script src="../../theme/js/jquery.easing.min.js"></script>
<script src="../../theme/js/scrollspy.min.js"></script>
<script src="../../theme/js/app.js"></script>';
        